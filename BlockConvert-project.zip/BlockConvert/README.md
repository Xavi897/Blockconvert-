# BlockConvert

React + TypeScript + Vite app with a Liquid Glass UI for a Minecraft world converter.

## Fitur saat ini

- UI Liquid Glass responsif untuk desktop dan HP.
- Animasi ambient, hover, progress bar, dan transisi.
- Pemilih format Java/Bedrock dan tombol tukar.
- Pilih atau drag-and-drop `.zip` / `.mcworld`.
- Validasi awal, status, dan penanganan error.
- Adapter engine terpisah untuk integrasi JE2BE.

## Jalankan

```bash
npm install
npm run dev -- --host 0.0.0.0
```

Build produksi:

```bash
npm run build
npm run preview -- --host 0.0.0.0
```

## Penting: engine konversi

Paket ini **belum mengandung engine JE2BE** dan belum dapat mengonversi world. Adapter sengaja menampilkan error sampai worker, JavaScript/WASM hasil build, dan protokol konversi upstream terintegrasi. Lihat [ENGINE-INTEGRATION.md](./ENGINE-INTEGRATION.md).

Upstream:
- https://github.com/kbinani/je2be-web
- https://github.com/kbinani/je2be-core

Periksa lisensi AGPL/GPL sebelum distribusi.
