# Menghubungkan engine JE2BE yang asli

BlockConvert saat ini adalah aplikasi React/Vite dengan UI, pemilihan format, upload file, validasi dasar, dan penanganan status. **Konversi belum aktif** sampai worker dan artefak WASM dari JE2BE-Web diintegrasikan.

## Repositori upstream

- Web app: https://github.com/kbinani/je2be-web
- Core: https://github.com/kbinani/je2be-core

JE2BE-Web memakai protokol worker dan build Emscripten yang spesifik pada versi upstream. Jangan menebak nama ekspor WASM atau menganggap `core.js` bisa dipanggil dengan API generik.

## Alur integrasi yang benar

1. Ambil source upstream dengan submodule sesuai petunjuk README upstream:
   `git clone --recurse-submodules https://github.com/kbinani/je2be-web.git`
2. Periksa `package.json`, `dev.ts`, `Makefile`, `Dockerfile`, `src/`, dan `public/` di versi tersebut.
3. Build engine dengan toolchain yang diminta upstream (termasuk Emscripten/Docker bila diperlukan).
4. Integrasikan worker, file JS hasil build, file WASM, dependensi, dan pesan progress/error dari versi yang sama. Jangan hanya menyalin `.wasm`.
5. Implementasikan `convertWorld()` di `src/engine/je2beAdapter.ts` menggunakan protokol worker upstream yang terverifikasi.
6. Pastikan output berupa byte hasil konversi dari engine, kemudian unduh sebagai arsip/format target yang benar.
7. Uji dengan salinan world kecil untuk dua arah konversi sebelum menyatakan fitur siap produksi.

## Status API aplikasi

UI memanggil:

```ts
convertWorld({
  file,
  source: "java" | "bedrock",
  target: "java" | "bedrock",
  onProgress(percent, message)
})
```

Adapter sengaja melempar error yang jelas sampai integrasi upstream dilakukan. Ini mencegah aplikasi mengembalikan file input seolah-olah hasil konversi.

## Catatan lisensi

JE2BE-Web berlisensi AGPL-3.0-or-later dan JE2BE Core berlisensi GPL-3.0. Periksa file lisensi dan kewajiban distribusi source/notices saat menggabungkan, memodifikasi, atau meng-host hasilnya. Jangan menghapus pemberitahuan hak cipta upstream.
