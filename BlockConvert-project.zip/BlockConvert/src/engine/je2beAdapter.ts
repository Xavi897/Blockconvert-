/**
 * Adapter boundary for the JE2BE-Web conversion engine.
 *
 * IMPORTANT:
 * The upstream converter is not a generic single-function WASM module.
 * Its worker protocol, generated JS/WASM files and dependencies must be
 * integrated from the matching upstream revision. This adapter deliberately
 * fails closed until that integration exists; it never pretends a conversion
 * succeeded or returns the original upload as a converted world.
 */

export type Edition = "java" | "bedrock";

export type ConvertOptions = {
  file: File;
  source: Edition;
  target: Edition;
  onProgress?: (percent: number, message: string) => void;
};

export type ConvertResult = {
  blob: Blob;
  filename: string;
};

export async function convertWorld(
  _options: ConvertOptions
): Promise<ConvertResult> {
  // Integration point:
  // 1. Add the matching JE2BE-Web worker and generated core JS/WASM artifacts.
  // 2. Use the worker message protocol from that exact upstream revision.
  // 3. Return the output bytes supplied by the engine only after success.
  throw new Error(
    "Engine JE2BE belum dipasang. Ikuti ENGINE-INTEGRATION.md untuk menghubungkan worker dan WASM dari JE2BE-Web."
  );
}

export function engineIsConfigured(): boolean {
  return false;
}