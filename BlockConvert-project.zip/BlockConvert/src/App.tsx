import { useRef, useState } from "react";
import {
  ArrowDownUp, ArrowRight, ArrowUpRight, Box, CheckCircle2, CircleHelp,
  CloudUpload, Cpu, FileArchive, FileCheck2, Github, LoaderCircle, LockKeyhole,
  Moon, Sun, Zap
} from "lucide-react";
import { convertWorld, engineIsConfigured, type Edition } from "./engine/je2beAdapter";

const editionName: Record<Edition, string> = {
  java: "Java Edition",
  bedrock: "Bedrock Edition"
};

export default function App() {
  const [source, setSource] = useState<Edition>("java");
  const [target, setTarget] = useState<Edition>("bedrock");
  const [file, setFile] = useState<File | null>(null);
  const [message, setMessage] = useState("Pilih format lalu upload world Minecraft kamu.");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [light, setLight] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function chooseFile(candidate?: File) {
    if (!candidate) return;
    const lower = candidate.name.toLowerCase();
    if (!lower.endsWith(".zip") && !lower.endsWith(".mcworld")) {
      setMessage("Format belum didukung di UI ini. Pilih file .zip atau .mcworld.");
      return;
    }
    if (candidate.size === 0) {
      setMessage("File kosong. Pilih world yang valid.");
      return;
    }
    setFile(candidate);
    setProgress(0);
    setMessage(`${candidate.name} · ${formatBytes(candidate.size)}`);
  }

  async function startConversion() {
    if (source === target) {
      setMessage("Pilih format asal dan tujuan yang berbeda.");
      return;
    }
    if (!file) {
      setMessage("Upload world terlebih dahulu.");
      inputRef.current?.click();
      return;
    }
    setBusy(true);
    setProgress(0);
    setMessage("Menyiapkan engine…");
    try {
      const result = await convertWorld({
        file, source, target,
        onProgress: (value, text) => {
          setProgress(value);
          setMessage(text);
        }
      });
      const url = URL.createObjectURL(result.blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = result.filename;
      link.click();
      URL.revokeObjectURL(url);
      setProgress(100);
      setMessage("Konversi selesai. File hasil diunduh.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Konversi gagal.");
    } finally {
      setBusy(false);
    }
  }

  function swap() {
    setSource(target);
    setTarget(source);
    setMessage("Format asal dan tujuan ditukar.");
  }

  return (
    <main className={`app ${light ? "light" : ""}`}>
      <div className="ambient ambient-a" />
      <div className="ambient ambient-b" />
      <div className="ambient ambient-c" />

      <header className="topbar glass">
        <a className="brand" href="#" aria-label="BlockConvert home">
          <span className="brand-mark"><Box size={25} strokeWidth={1.7} /></span>
          <span className="brand-copy">
            <strong>BlockConvert</strong>
            <small>Minecraft World Converter</small>
          </span>
        </a>
        <div className="top-actions">
          <span className={`engine-pill ${engineIsConfigured() ? "ready" : ""}`}>
            <span /> {engineIsConfigured() ? "Engine ready" : "Engine setup"}
          </span>
          <button className="icon-button" onClick={() => setLight(!light)} aria-label="Ganti tema">
            {light ? <Moon size={18} /> : <Sun size={18} />}
          </button>
        </div>
      </header>

      <section className="hero">
        <div className="eyebrow"><span className="pulse-dot" /> WORLD CONVERTER</div>
        <h1>Every world has<br /><span>another life.</span></h1>
        <p>Konversi dunia Minecraft dengan alur yang sederhana.<br className="desktop-only" /> Pilih format, masukkan world, lalu proses.</p>
      </section>

      <section className="converter glass">
        <div className="steps">
          <div className="step active"><span>01</span><small>Format</small></div>
          <div className="step-line" />
          <div className={`step ${file ? "active" : ""}`}><span>02</span><small>Upload</small></div>
          <div className="step-line" />
          <div className={`step ${progress === 100 ? "active" : ""}`}><span>03</span><small>Convert</small></div>
        </div>

        <div className="format-row">
          <FormatCard title="FROM" value={source} onChange={setSource} />
          <button className="swap-button" onClick={swap} title="Tukar format" aria-label="Tukar format">
            <ArrowDownUp size={18} />
          </button>
          <FormatCard title="TO" value={target} onChange={setTarget} />
        </div>

        <input
          ref={inputRef}
          className="file-input"
          type="file"
          accept=".zip,.mcworld"
          onChange={(event) => chooseFile(event.currentTarget.files?.[0])}
        />
        <button
          className={`dropzone ${file ? "selected" : ""}`}
          onClick={() => inputRef.current?.click()}
          onDragOver={(event) => event.preventDefault()}
          onDrop={(event) => {
            event.preventDefault();
            chooseFile(event.dataTransfer.files?.[0]);
          }}
        >
          <span className="upload-symbol">{file ? <FileCheck2 size={30} /> : <CloudUpload size={32} />}</span>
          <strong>{file ? file.name : "Drop your world here"}</strong>
          <span>{file ? `${formatBytes(file.size)} · Klik untuk mengganti file` : "Klik untuk memilih file dari perangkat"}</span>
          <small>ZIP / MCWORLD</small>
        </button>

        {busy && (
          <div className="progress-wrap">
            <div className="progress-label"><span>Conversion progress</span><span>{progress}%</span></div>
            <div className="progress-track"><div style={{ width: `${progress}%` }} /></div>
          </div>
        )}

        <button className="convert-button" disabled={busy} onClick={startConversion}>
          {busy ? <LoaderCircle className="spin" size={18} /> : <Zap size={17} />}
          <span>{busy ? "Memproses…" : "Mulai Konversi"}</span>
          {!busy && <ArrowRight size={18} />}
        </button>

        <div className="status" role="status">
          <span className="status-dot" />
          <span>{message}</span>
        </div>
      </section>

      <section className="features">
        <Feature icon={<Zap size={19} />} title="Alur simpel" desc="Fokus pada world kamu" />
        <Feature icon={<LockKeyhole size={19} />} title="Privasi" desc="Target pemrosesan lokal" />
        <Feature icon={<Cpu size={19} />} title="JE2BE Core" desc="Engine perlu diintegrasikan" />
      </section>

      <div className="notice glass">
        <CircleHelp size={17} />
        <p><strong>Status pengembangan:</strong> antarmuka dan upload sudah aktif. Engine konversi belum disertakan di paket ini; aplikasi akan menampilkan error dengan jelas, bukan mengklaim konversi berhasil.</p>
      </div>

      <footer>
        <span>BLOCKCONVERT <b>v1.0.0</b></span>
        <span className="footer-links"><a href="https://github.com/kbinani/je2be-web" target="_blank" rel="noreferrer"><Github size={13} /> JE2BE-Web source</a><span>•</span><span>Built for worlds</span><ArrowUpRight size={13} /></span>
      </footer>
    </main>
  );
}

function FormatCard({ title, value, onChange }: {
  title: string;
  value: Edition;
  onChange: (value: Edition) => void;
}) {
  return (
    <label className="format-card">
      <span className="format-label">{title}</span>
      <span className="format-select-wrap">
        <span className="edition-icon"><Box size={19} /></span>
        <select value={value} onChange={(event) => onChange(event.target.value as Edition)}>
          <option value="java">Java Edition</option>
          <option value="bedrock">Bedrock Edition</option>
        </select>
      </span>
      <span className="card-glint" />
    </label>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <article className="feature glass">
      <span className="feature-icon">{icon}</span>
      <span><strong>{title}</strong><small>{desc}</small></span>
    </article>
  );
}

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}